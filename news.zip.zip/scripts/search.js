// import sidebar from "./components/sidebar.js";

function storeSearchterm(term) {

    
}

export default storeSearchterm
function sidebar() {
    return `<div>Login</div>
    <div>StartUps</div>
    <input type="text" id="searchbar">
    <div>NewsLetter</div>
    <div>Audio</div>
    <div>Video</div>`

    // return your html component here
    //Make sure to give input search box id as ""
}
export default sidebar